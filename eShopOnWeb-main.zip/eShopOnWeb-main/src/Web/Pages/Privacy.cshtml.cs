﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Microsoft.eShopWeb.Web.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}
